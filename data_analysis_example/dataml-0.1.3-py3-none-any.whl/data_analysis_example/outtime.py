from data_analysis_example.init_model_ml1 import mlModel

if __name__ == '__main__':
    # mlModel.outtime(model_type='lr')
    mlModel.outtime(model_type='lgb',encoder_type='onehot')