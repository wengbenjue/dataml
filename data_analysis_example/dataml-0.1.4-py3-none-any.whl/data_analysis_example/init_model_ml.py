from dataml.ml_model import MLModel
from dataml.model.lightgbm_model import LightGBMModel
from dataml.model.logistic_regression_model import LogisticRegressionModel
from dataml.feature_explain import ShapFeatureExplain
from dataml.datasets import SQLDataset, DefaultWarehouse

import os
from dataml.feature_process import (
    FeatureProcess,
    MissValueFeatureProcess,
    MostValueValueFeatureProcess,
    VarDerivaticeFeatureProcess,
    VarianceThresholdFeatureProcess,
    OutlierFeatureProcess,
    QuartileFeatureProcess,
    MissValueFillFeatureProcess,
    IVFeatureProcess,
    CorrFeatureProcess,
    CSIFeatureProcess,
    ForestFeatureProcess,
    VarDropFeatureProcess,
    CatClusterValueFeatureProcess
)

from dataml.feature_encoder import (
OnehotEncoder,
WoeEncoder
)


cache_dir = './data/'
model_dir = './models/'
# 参数设置
need_reload_data = False
warehouse_address = 'postgresql://user:passwd@10.210.126.11:5432/warehouse'
train_prv_big_tablename = 'yecPRV_Market_CUST_INFO_BIG_TABLE'
pred_prv_big_tablename = 'yecPRV_Market_CUST_INFO_BIG_TABLE'
pred_cpct_big_tablename = 'yecCPCT_Market_CUST_INFO_BIG_TABLE'
outtime_prv_big_tablename = 'yec_PRV_Market_CUST_INFO_BIG_TABLE'
outtime_cpct_big_tablename = 'yecCPCT_Market_CUST_INFO_BIG_TABLE'
cst_base_info_tablename = 'YEC.CST_TOUCH_BASE_INFO'

dtype={
    'cst_base_sz_cd': 'str',
    'cst_sbdvn_cd': 'str',
}
index_col ='cst_id'
rename_columns = {
    'label_cd_x':'label_cd'
}
dt_name = 'data_dt'
watch_point='2023-08-01'
oot_watch_point='2023-08-01'
pre_watch_point='2023-08-01'

train_prv_sql = 'select* from ...'
train_cpct_sql = 'select* from ...'
outtime_prv_sql = 'select* from ...'
outtime_cpct_sql = 'select* from ...'

pred_prv_sql = 'select* from ...'
pred_cpct_sql = 'select* from ...'

cst_base_info_sql = 'select * from'


drop_columns=['first_push_time']

#特征处理
miss_rate=0.85 #缺失率阈值
same_value_rate=0.85 #同值率剔除阈值
y_target='label_cd' #目标Y字段名

v_threshold = 0.01 #方差剔除阈值
min_value_count = 100 #类别变量最低要求频数
stats_file = os.path.join(model_dir,'state_file.json') #缺失率填充分布序列化文件名

#IV
bin_method = 'tree' #分箱方法，tree | chimerge 决策树或卡方分箱
min_iv_limit=0.02
max_iv_limit=0.5
#相关性系数剔除
corr_threshold=-.85 #皮尔逊相关性系数剔除阈值

#稳定性剔除
csi_threshold=0.85 #CSI稳定性剔除阈值

#树模型剔除变量
forest_select_cumulative_importance=0.95 #树模型累计重要性阈值
forest_select_max_depth=3 #树的最大深度

#模型参数
lr_explain_models = None #
#类别权重 逻辑回归
class_weight= 'balanced'
class_weights= [{1:1.0,0:1.0},{1:2.0,0:1.0}]
#是否需要超参优化
params_optimize=False

#数据字典映射配置
sheet_name = 'Sheet1'
var_zh_name='字段中文名'
var_en_name='字段英文名'

need_pre_process=True #是否需要数据预处理
data_dict_path= os.path.join(cache_dir,'企业级用户客户标签_数据字典_V202309.xlsm')

#出清单配置
outlist_table_name = 'outputlist'
#表scheme
scheme = 'ngb620view'

#营销设置
user_profile_label_rules = [
    [['星座','学历','行业','对公客户类型'],['高端对公客户','金融贸易精英','品质生活家']],
    [['员工人数','注册资金金额','近12个月电子银行交易笔数','产品覆盖数'],['中大型企业客户','电子银行活跃客户','交易优质客户']],
]

default_warehouse = DefaultWarehouse(warehouse_address=warehouse_address, need_reload_data=need_reload_data)

uni_feature_process = [
    VarDropFeatureProcess(drop_columns=drop_columns),
    VarDerivaticeFeatureProcess(),
    CatClusterValueFeatureProcess(min_value_count=min_value_count, y_target=y_target),
    MissValueFeatureProcess(miss_rate=miss_rate),
    MostValueValueFeatureProcess(same_value_rate=same_value_rate, y_target=y_target),
    VarianceThresholdFeatureProcess(v_threshold=v_threshold, y_target=y_target),
    OutlierFeatureProcess(cache_dir=cache_dir, y_target=y_target),
    QuartileFeatureProcess(y_target=y_target),
    MissValueFillFeatureProcess(stats_file=stats_file,y_target=y_target)
]

double_feature_process = [
    IVFeatureProcess(bin_method=bin_method, min_iv_limit=min_iv_limit, max_iv_limit=max_iv_limit,
                     model_dir=model_dir, y_target=y_target),
    CorrFeatureProcess(corr_threshold=corr_threshold, y_target=y_target),
    CSIFeatureProcess(csi_threshold=csi_threshold, model_dir=model_dir, y_target=y_target),
    ForestFeatureProcess(miss_rate=miss_rate,corr_threhold=corr_threshold,
                         forest_select_cumutative_importance=forest_select_cumulative_importance,
                         max_depth=forest_select_max_depth,y_target=y_target)
]

oot_feature_process = [
    OutlierFeatureProcess(cache_dir=cache_dir,y_target=y_target),
    MissValueFillFeatureProcess(stats_file=stats_file,y_target=y_target)
]

csi_feature_process = [
    CatClusterValueFeatureProcess(min_value_count=min_value_count,y_target=y_target),
    OutlierFeatureProcess(cache_dir=cache_dir,y_target=y_target),
    MissValueFillFeatureProcess(stats_file=stats_file,y_target=y_target)
]

lgb_explain_models = [ShapFeatureExplain]


mlModel=MLModel(
    cache_dir = cache_dir
    ,y_target = y_target
    ,need_reduce_dim = False
    ,need_visuz = False
    ,need_tsne_visuz = False
    ,need_recall_negative=True
    ,negative_sim_threshold = 0.35
    ,test_ratio=0.2
    ,min_lift=1.5
    ,drop_columns= drop_columns
    ,train_dataset=LocalDataset(data_path=train_file_path, index_col=index_col)
    ,oot_dataset= LocalDataset(data_path=train_file_path, index_col=index_col)
    ,pred_dataset= LocalDataset(data_path=pred_file_path, index_col=index_col)
    ,out_dataset= LocalDataset(data_path=train_file_path, index_col=index_col)
    ,cst_base_info_dataset =LocalDataset(data_path=train_file_path, index_col=index_col)
    ,models=[LogisticRegressionModel(explain_models=[lr_explain_models], class_weight=class_weight,
                                    class_weights=class_weights)
            ,LightGBMModel(explain_models=[lgb_explain_models],params_optimize=params_optimize)]
    ,uni_feature_process = uni_feature_process
    ,double_feature_process=double_feature_process
    ,oot_feature_process=oot_feature_process
    ,csi_feature_process=csi_feature_process
    ,feature_encoder = OnehotEncoder(model_dir=model_dir,y_target=y_target)
    ,sheet_name=sheet_name
    ,var_zh_name=var_zh_name
    ,var_en_name=var_en_name
    ,need_pre_process=need_pre_process
    ,user_profile_label_rules=user_profile_label_rules
)







